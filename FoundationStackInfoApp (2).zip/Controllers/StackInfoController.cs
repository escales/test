
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using FoundationStackInfoApp.Models;
using System.IO;

namespace FoundationStackInfoApp.Controllers
{
    public class StackInfoController : Controller
    {
        public IActionResult Index()
        {
            var jsonFilePath = Path.Combine(Directory.GetCurrentDirectory(), "foundation-stack-info.json");
            var stackInfoList = new List<StackInfo>();

            if (System.IO.File.Exists(jsonFilePath))
            {
                var jsonData = System.IO.File.ReadAllText(jsonFilePath);
                stackInfoList = JsonConvert.DeserializeObject<List<StackInfo>>(jsonData);
            }

            return View(stackInfoList);
        }
    }
}
