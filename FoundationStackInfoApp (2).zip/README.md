
# Foundation Stack Info App for PCF (Air-Gapped Environment)

This .NET 6 application displays foundation stack information in a table format on a webpage. This project includes all necessary files to restore and publish dependencies locally for deployment to an air-gapped PCF environment.

## Steps for Publishing Dependencies Locally

1. **Restore and Publish Project with Dependencies**
   - Open a terminal in the project root directory (`FoundationStackInfoApp`).
   - Run the following command to publish all dependencies for a Linux environment (replace with your platform as needed):
     ```bash
     dotnet publish -c Release -o publish --self-contained --runtime linux-x64
     ```

2. **Push to PCF**
   - Ensure that your `cf` CLI is connected to the air-gapped environment.
   - Use the following command to push the app to PCF:
     ```bash
     cf push
     ```

This process will publish all dependencies to the `publish` directory, ensuring no external network requests are needed during deployment.
