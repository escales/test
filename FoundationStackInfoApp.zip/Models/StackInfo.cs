
namespace FoundationStackInfoApp.Models
{
    public class StackInfo
    {
        public string App { get; set; }
        public string Org { get; set; }
        public string Space { get; set; }
        public string Stack { get; set; }
    }
}
