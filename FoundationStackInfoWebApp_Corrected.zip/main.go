package main

import (
    "html/template"
    "net/http"
    "log"
)

func main() {
    http.HandleFunc("/", loginHandler)
    http.HandleFunc("/dashboard", dashboardHandler)
    log.Fatal(http.ListenAndServe(":8080", nil))
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
    tmpl := template.Must(template.ParseFiles("templates/login.html"))
    tmpl.Execute(w, nil)
}

func dashboardHandler(w http.ResponseWriter, r *http.Request) {
    // Retrieve token, fetch application data, and render dashboard
    tmpl := template.Must(template.ParseFiles("templates/dashboard.html"))
    data := struct {
        Apps []struct {
            Name  string
            Org   string
            Space string
            Stack string
        }
    }{
        Apps: []struct {
            Name  string
            Org   string
            Space string
            Stack string
        }{
            {"Sample App", "Org1", "Space1", "cflinuxfs3"},
        },
    }
    tmpl.Execute(w, data)
}
