package main

import (
    "encoding/json"
    "fmt"
    "html/template"
    "log"
    "net/http"
)

type App struct {
    Name  string
    Org   string
    Space string
    Stack string
}

type ProgressUpdate struct {
    Message   string `json:"message"`
    TableHTML string `json:"tableHTML,omitempty"`
    Complete  bool   `json:"complete"`
}

func dashboardHandler(w http.ResponseWriter, r *http.Request) {
    tmpl := template.Must(template.ParseFiles("templates/dashboard.html"))
    tmpl.Execute(w, nil)
}

func progressHandler(w http.ResponseWriter, r *http.Request) {
    flusher, ok := w.(http.Flusher)
    if !ok {
        http.Error(w, "Streaming unsupported!", http.StatusInternalServerError)
        return
    }
    w.Header().Set("Content-Type", "text/event-stream")
    w.Header().Set("Cache-Control", "no-cache")
    w.Header().Set("Connection", "keep-alive")

    token := "your_token_here" // replace with the actual token
    var allApps []App
    orgs, _ := getOrgs(token)

    for _, orgGUID := range orgs {
        spaces, _ := getSpaces(token, orgGUID)
        sendProgressUpdate(w, fmt.Sprintf("Loading spaces in organization %s...", orgGUID), false)
        
        for _, spaceGUID := range spaces {
            apps, _ := getApps(token, spaceGUID)
            for _, app := range apps {
                app.Org = orgGUID
                app.Space = spaceGUID
                allApps = append(allApps, app)
            }
            sendProgressUpdate(w, fmt.Sprintf("Processed space %s in org %s", spaceGUID, orgGUID), false)
        }
    }

    tableHTML := buildTableHTML(allApps)
    sendProgressUpdate(w, "Data retrieval complete.", true, tableHTML)

    flusher.Flush()
}

func sendProgressUpdate(w http.ResponseWriter, message string, complete bool, tableHTML ...string) {
    update := ProgressUpdate{
        Message:  message,
        Complete: complete,
    }
    if len(tableHTML) > 0 {
        update.TableHTML = tableHTML[0]
    }

    json.NewEncoder(w).Encode(update)
    fmt.Fprint(w, "

")
    if flusher, ok := w.(http.Flusher); ok {
        flusher.Flush()
    }
}

func buildTableHTML(apps []App) string {
    var tableHTML string
    for _, app := range apps {
        row := fmt.Sprintf("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>", app.Name, app.Org, app.Space, app.Stack)
        tableHTML += row
    }
    return tableHTML
}

func main() {
    http.HandleFunc("/", dashboardHandler)
    http.HandleFunc("/progress", progressHandler)
    log.Fatal(http.ListenAndServe(":8080", nil))
}
