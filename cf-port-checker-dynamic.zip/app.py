from flask import Flask, request, render_template_string
import subprocess
import tempfile

app = Flask(__name__)

TEMPLATE = """
<!doctype html>
<html>
<head><title>Port Checker</title></head>
<body>
  <h1>Port Checker - Dynamic Input</h1>
  <form method="post">
    <textarea name="targets" rows="10" cols="60">{{ targets }}</textarea><br>
    <button type="submit">Check</button>
  </form>
  {% if output %}
  <h2>Result</h2>
  <pre>{{ output }}</pre>
  {% endif %}
</body>
</html>
"""

@app.route('/', methods=['GET', 'POST'])
def index():
    output = ''
    targets = ''
    if request.method == 'POST':
        targets = request.form['targets']
        with tempfile.NamedTemporaryFile(mode='w+', delete=False) as tf:
            tf.write(targets)
            tf.flush()
            result = subprocess.run(['bash', 'check_targets.sh', tf.name],
                                    capture_output=True, text=True)
            output = result.stdout
    return render_template_string(TEMPLATE, output=output, targets=targets)
