#!/bin/bash

FILE=${1:-targets.txt}
echo "Starting IP/Port checks..."

while read -r HOST PORT; do
  if [[ -z "$HOST" || -z "$PORT" ]]; then
    continue
  fi
  echo "Checking $HOST:$PORT..."
  if nc -zv -w 3 "$HOST" "$PORT" 2>&1; then
    echo "✅ $HOST:$PORT is reachable."
  else
    echo "❌ $HOST:$PORT is not reachable."
  fi
done < "$FILE"
