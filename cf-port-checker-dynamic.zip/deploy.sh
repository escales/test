#!/bin/bash

# Generate random suffix
RAND_SUFFIX=$(cat /dev/urandom | tr -dc 'a-z0-9' | fold -w 6 | head -n 1)
APP_NAME="cf-port-checker-${RAND_SUFFIX}"

# Replace in manifest and deploy
cp manifest.yml manifest.tmp.yml
sed -i '' "s/cf-port-checker-REPLACE_ME/${APP_NAME}/" manifest.tmp.yml

echo "Deploying as ${APP_NAME}..."

cf push -f manifest.tmp.yml

# Clean up
rm manifest.tmp.yml
